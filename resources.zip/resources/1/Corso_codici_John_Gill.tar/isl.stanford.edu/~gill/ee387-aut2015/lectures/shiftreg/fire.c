#include <stdio.h>

char *binrep(unsigned v, int n, char *s)
{
  int i;
  for (i = 0; i < n; i++) {
    s[i] = '0' + ((v >> i) & 1);
  }
  s[n] = '\0';
  return s;
}

int main(int argc, char **argv)
{
  unsigned g = 0x993;
  unsigned g0 = 0x81, g1 = 0x13;
  unsigned m = 0xa5a;
  unsigned c, e, r, s0, s1, b;
  int i, i0, i1;
  char buf[100], buf2[100];

  c = 0;
  for (i = 0; i < 12; i++) {
    if (m & (1<<i))
      c ^= g << i;
  }
  printf("c = %s\n", binrep(c, 24, buf));
  e = 0xb << 12;
  r = c ^ e;
  printf("r = %s\n", binrep(r, 24, buf));

  /* calculate syndromes */
  s0 = 0;
  s1 = 0;
  for (i = 0; i < 24; i++) {
    int bit = (r >> (23 - i)) & 1;
    s0 = (s0 << 1) ^ bit;
    if (s0 & (1<<7)) s0 ^= g0;
    s1 = (s1 << 1) ^ bit;
    if (s1 & (1<<4)) s1 ^= g1;
    printf("%s %s\n", binrep(s0, 7, buf), binrep(s1, 4, buf2));
  }
  printf("------- ----\n");

  /* shift s0 until burst is identified */
  for (i = 0; i < 7; i++) {
    printf("%d %s\n", (7 - i) % 7, binrep(s0, 7, buf));
    if ((s0 & 0xf0) == 0)
      break;
    if ((s0 <<= 1) & (1<<7)) s0 ^= g0;
  }
  b = s0;
  i0 = (7 - i) % 7;
  printf("b = %s\n", binrep(b, 4, buf));
  for (i = 0; i < 15; i++) {
    printf("%d %s\n", (15 - i) % 15, binrep(s1, 4, buf));
    if (s1 == b)
      break;
    if ((s1 <<= 1) & (1<<4)) s1 ^= g1;
  }
  i1 = (15 - i) % 15;
  printf("i0 = %d  i1 = %d\n", i0, i1);
  exit(0);
}
