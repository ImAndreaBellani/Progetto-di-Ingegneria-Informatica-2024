#!/usr/bin/perl -w

$x = '0011';
$y = '0101';
print $x ^ $y, "\n";
