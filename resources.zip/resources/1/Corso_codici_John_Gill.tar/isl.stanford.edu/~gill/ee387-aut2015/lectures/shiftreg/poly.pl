#!/usr/bin/perl -w

print <<EOM;
GF(4) = {0, 1, b, d}
b + d = 1 ; b * d = 1
EOM

@g1 = (1,2,2,1,1,3,1);
$g[0] = $g1[0];
$g[$_] = $g1[$_] ^ $g1[$_-1] for (1..$#g1);
push @g, $g1[$#g1];
printf "g = %s\n", betadelta(@g);

@m = (1,0,2,3,3,1,2,1);
printf "m = %s\n", betadelta(@m);
print "\n";

print "Multiplication\n\n";
printf "%30s\n", betadelta(@g);
printf "%30s\n", betadelta(@m);
printf "%30s\n", "-" x 15;
@c = ();
for ($i = $#m; $i >= 0; $i--) {
  for $j (0..$#g) {
    $t[$j] = gf4mul($m[$i], $g[$j]);
    $c[$i + $j] ^= $t[$j];
  }
  printf "%s%s\n", "  " x $i, betadelta(@t);
}
printf "%30s\n", "-" x 30;
printf "%30s\n", betadelta(@c);
print "\n";

@r = (1,3,2,1,1,0,1,0,2,3,3,2,0,0,1);

print "Division\n\n";
printf "%30s\n", betadelta(@r);
printf "%30s\n", "-" x 30;
for ($i = $#r - $#g; $i >= 0; $i--) {
  for $j (0..$#g) {
    $t[$j] = gf4mul($r[$#g + $i], $g[$j]);
    $u[$j] = ($r[$i + $j] ^= $t[$j]);
  }
  printf "%s%s\n", "  " x $i, betadelta(@t);
  pop @u;
  printf "%s%s\n", "  " x $i, betadelta(@u);
}

sub betadelta {
  my $t = " @_";
  $t =~ y/23/bd/;
  return $t;
}

sub gf4mul {
  my ($a, $b) = @_;
  return $GF4multab[$a][$b];
}

BEGIN {
  @GF4multab = (
    [ 0, 0, 0, 0 ],
    [ 0, 1, 2, 3 ],
    [ 0, 2, 3, 1 ],
    [ 0, 3, 1, 2 ],
  );
}
