#!/usr/bin/perl

$n = 255;
$bn[0] = 1;
$v[0] = 1;
for $i (1..127) {
  $bn[$i] = $bn[$i-1] * ($n-$i+1) / $i;
  $v[$i] += $bn[$i];
  printf "%3d & %5.1f\\\\\n", $i, int((log($v[$i])/log(2))+0.9999);
}
