#!/usr/bin/perl -w

# verify that p(x) is primitive

@p = qw(1 2 0);
@z = qw(1 0 0);
for $i (1..27) {
  print "@z\n";
  $msb = pop @z;
  unshift @z, 0;
  $z[$_] = ($z[$_] - $msb * $p[$_]) % 3 for (0..2);
}

# systematic Hamming check matrix

@g = qw(2 1 1);
print "H =\n";
@z = qw(1 0 0);
for $i (1..12) {
  print "@z\n";
  $msb = pop @z;
  unshift @z, 0;
  $z[$_] = ($z[$_] - $msb * $g[$_]) % 3 for (0..2);
}
